<footer class="blog-footer">
    <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?></p>
    <p>
        <a href="#"><?php _e('Back to top', 'bootstrap4'); ?></a>
    </p>
</footer>
<?php wp_footer(); ?>