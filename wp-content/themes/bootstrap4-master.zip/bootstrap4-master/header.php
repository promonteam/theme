<div class="blog-header">
    <div class="container">
        <h1 class="blog-title"><a href="<?php echo get_home_url(); ?>"><?php bloginfo('name'); ?></a></h1>
        <p class="lead blog-description"><?php bloginfo('description'); ?></p>
    </div>
</div>