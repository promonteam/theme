# Bootstrap 4 Theme for Wordpress

**Take care! The theme is still in pre-alpha stage and not safe for production! Nevertheless, feel free to contribute!**

Developer: Jan-Lukas Else

## Features

* Lightweight
* Uses Bootstrap 4 Alpha 5
* Featured images on single post pages too
* Direct Disqus integration
* Infinite Scroll Support (requires Jetpack)

## License

    Bootstrap 4 Theme for Wordpress
    Copyright (C) 2016 Jan-Lukas Else

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.